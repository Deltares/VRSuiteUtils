# Common module

This module is intended to contain all shared components between the components in the application.