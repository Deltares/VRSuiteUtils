from pathlib import Path

default_scripts_dir = Path(__file__).parent.joinpath("scripts")
