from vrtool.decision_making.measures.standard_measures.revetment_measure.revetment_measure import (
    RevetmentMeasure,
)
