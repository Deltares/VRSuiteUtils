from vrtool.failure_mechanisms.revetment.slope_part.asphalt_slope_part import (
    AsphaltSlopePart,
)
from vrtool.failure_mechanisms.revetment.slope_part.grass_slope_part import (
    GrassSlopePart,
)
from vrtool.failure_mechanisms.revetment.slope_part.slope_part_builder import (
    SlopePartBuilder,
)
from vrtool.failure_mechanisms.revetment.slope_part.slope_part_protocol import (
    SlopePartProtocol,
)
from vrtool.failure_mechanisms.revetment.slope_part.stone_slope_part import (
    StoneSlopePart,
)
