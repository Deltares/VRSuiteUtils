import subprocess
from pathlib import Path

import numpy as np
import openturns as ot
import pandas as pd

from vrtool.probabilistic_tools.probabilistic_functions import TableDist


# script to run HydraRing. exelocation should refer to the location of MechanismComputation.exe.
def run_hydraring(
    inifile: Path,
    exelocation=r"C:\Program Files (x86)\BOI\Riskeer 21.1.1.2\Application\Standalone\Deltares\HydraRing-20.1.3.10236\MechanismComputation.exe",
):
    subprocess.run([exelocation, str(inifile)], cwd=str(inifile.parent))


# write a design table to a OpenTurns TableDist as defined by ProbabilisticFunctions.TableDist
def design_table_openturns(filename: Path, gridpoints=2000):
    data = read_design_table(filename)
    wls = list(data.iloc[:, 0])
    # wls = np.subtract(wls, 0.5)
    p_nexc = list(1 - data.iloc[:, 1])
    h = TableDist(np.array(wls), np.array(p_nexc), extrap=True, isload=True)
    h = ot.Distribution(
        TableDist(
            np.array(wls),
            np.array(p_nexc),
            extrap=True,
            isload=True,
            gridpoints=gridpoints,
        )
    )
    return h


def read_design_table(filename: Path):
    import re

    values = []
    count = 0
    f = open(filename, "r")
    for line in f:
        if count == 0:
            headers = re.split("  +", line)[1:]
        else:
            val = re.split("  +", line)[1:]
            val = [i.replace("\n", "") for i in val]
            val = [float(i) for i in val]
            values.append(val)
        count += 1
    data = pd.DataFrame(values, columns=headers).rename(columns={"Beta\n": "Beta"})
    f.close()
    return data
