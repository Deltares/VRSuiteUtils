# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vrtool',
 'vrtool.common',
 'vrtool.common.hydraulic_loads',
 'vrtool.decision_making',
 'vrtool.decision_making.measures',
 'vrtool.decision_making.strategies',
 'vrtool.defaults',
 'vrtool.failure_mechanisms',
 'vrtool.failure_mechanisms.general',
 'vrtool.failure_mechanisms.overflow',
 'vrtool.failure_mechanisms.piping',
 'vrtool.failure_mechanisms.stability_inner',
 'vrtool.flood_defence_system',
 'vrtool.orm',
 'vrtool.orm.io',
 'vrtool.orm.io.exporters',
 'vrtool.orm.io.importers',
 'vrtool.orm.models',
 'vrtool.post_processing',
 'vrtool.probabilistic_tools',
 'vrtool.run_workflows',
 'vrtool.run_workflows.measures_workflow',
 'vrtool.run_workflows.optimization_workflow',
 'vrtool.run_workflows.safety_workflow']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.3,<9.0.0',
 'd-geolib>=0.6.0,<0.7.0',
 'matplotlib>=3.7.0,<4.0.0',
 'openpyxl>=3.1.1,<4.0.0',
 'openturns==1.19',
 'pandas>=1.5.3,<2.0.0',
 'peewee>=3.16.1,<4.0.0',
 'scipy==1.8.1',
 'seaborn>=0.12.2,<0.13.0',
 'shapely>=2.0.1,<3.0.0']

setup_kwargs = {
    'name': 'vrtool',
    'version': '0.0.2',
    'description': '',
    'long_description': '[![Python 3.10](https://img.shields.io/badge/Python-3.10-blue.svg)](https://www.python.org/downloads/release/python-3109/)\n[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)\n[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=Deltares_Veiligheidsrendement&metric=alert_status&token=483801771f090b3ceb93ef315f0332003a075970)](https://sonarcloud.io/summary/new_code?id=Deltares_Veiligheidsrendement)\n![TeamCity build status](https://dpcbuild.deltares.nl/app/rest/builds/buildType:id:Vrtool_RunAcceptanceTests_RunPytest/statusIcon.svg)\n\n# Veiligheidsrendement #\n\nThis is the repository as developed in the AllRisk programme to apply the veiligheidsrendementmethode for optimal planning of flood defence systems.\n\n## What is this repository for?\n\n* Quick summary\n* Version\n\n## How do I get set up? ##\n\n__Important!__ The following installation steps are written based on a Windows environment. When using other systems (which should be possible) it might be required to use different commands. However, the fundamental of the installation steps should remain the same. This meaning, no additional packages or libraries should be required. If problems would arose during your installation, please contact the maintainers of the tool.\n\n### Sandbox / Endpoint\n\nWhen you only require the `VeiligheidsrendementTool` package to be used as a whole, and not for developments, we advise to directly use the latest greatest release, or directly the latest available version from `main` as follows:\n\n1. Latest available `main`:\n```bash\npip install git+https://github.com/Deltares/Veiligheidsrendement.git\n```\n\n2. Specific `Veiligheidsrendement` version, add `@version-tag` to the previous command, for instance install tag `v0.0.1` (__Proof of Concept__ previous to this GIT repository):\n```bash\npip install git+https://github.com/Deltares/Veiligheidsrendement.git@v0.0.1\n```\n| You can also do the above with a commit-hash for development branches (e.g.:`@40bd07d`)\n\n\n### Development mode\n\nWe recommend you to check our `CONTRIBUTING.md` document and its [installation steps section](./docs/CONTRIBUTING.md#install-before-contributing).\n\n\n### Dependencies / Pre-requirements.\n\n#### D-Stability\nIt is the responsibility of the user to have their own DStabilityConsole binaries locally available in order to run it with the `vrtool`. For a correct functioning we advise you to have a look on our tutorial section [Running a D-Stability model](https://deltares.github.io/VrtoolDocumentation/tutorials/vrtool_tutorial.html#running-a-d-stability-model).\n\n#### openturns\nWe found out a hard dependency when working under a Windows environment with the [library `openturns`](https://openturns.github.io/www/index.html), which forced us to work under the version 1.19. This is automatically resolved for you when following the steps specified for [development mode](#development-mode).\nWhen using your own environment, you might have to follow the openturns installation steps for version 1.19.\n\n### How to run tests\nTests can be run with the pytest command `pytest run`. However, when working under a [development mode](#development-mode) environment, we advise to run the command `poetry run pytest` instead.\n\n\n## Endpoint usage\n \nWhen using `Veiligheidsrendement` as a package (`vrtool`) you can run it directly from the command line as follows:\n\n```cli\npython -m vrtool {desired_run} {MODEL_DIRECTORY}\n```\nThe run options are:\n- `assessment`: Runs a validation of the model in the given MODEL_DIRECTORY.\n- `measures`: Runs measurements of all specified mechanisms in the model.\n- `optimization`: Runs an optimization of the model including the previous measures run.\n- `run_full`: Runs all the steps above sequentially.\n\nThe arguments are:\n- `MODEL_DIRECTORY` (required): Absolute path to the location of your model directory. It expects a `*.json` file containing the configuration to be run.\n\nIt is also possible to check all the above possibilities via the `--help` argument in the command line:\n```cli\npython -m vrtool --help\n```\n\n## Contribution guidelines ##\n\nTo know how to collaborate within this project please refer to our [contributing page](./docs/CONTRIBUTING.md).\n\n## Who do I talk to? ##\n\n* Repo owner or admin\n* Other community or team contact\n',
    'author': 'Wouter Jan Klerk',
    'author_email': 'wouterjan.klerk@deltares.nl',
    'maintainer': 'Carles S. Soriano Pérez',
    'maintainer_email': 'carles.sorianoperez@deltares.nl',
    'url': 'https://github.com/Deltares/veiligheidsrendement',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
